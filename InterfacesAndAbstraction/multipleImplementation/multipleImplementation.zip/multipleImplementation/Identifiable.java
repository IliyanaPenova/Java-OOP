package multipleImplementation;

public interface Identifiable {
    String getId();
}
