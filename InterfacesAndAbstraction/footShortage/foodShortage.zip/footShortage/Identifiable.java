package footShortage;

public interface Identifiable {
    String getId();
}
