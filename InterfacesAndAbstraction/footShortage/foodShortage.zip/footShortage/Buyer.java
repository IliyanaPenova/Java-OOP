package footShortage;

public interface Buyer {
    void buyFood();
    int getFood();
}
