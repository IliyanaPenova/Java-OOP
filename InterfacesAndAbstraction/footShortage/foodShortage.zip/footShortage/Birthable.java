package footShortage;

public interface Birthable {
    String getBirthDate();
}
