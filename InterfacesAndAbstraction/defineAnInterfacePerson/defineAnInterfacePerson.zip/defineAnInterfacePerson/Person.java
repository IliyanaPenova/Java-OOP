package InterfacesAndAbstraction.defineAnInterfacePerson;

public interface Person {
    String getName();

    int getAge();
}
