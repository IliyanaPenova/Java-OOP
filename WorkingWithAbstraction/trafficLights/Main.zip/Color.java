package WorkingWithAbstraction.trafficLights;

public enum Color {
    RED,
    YELLOW,
    GREEN;
}
